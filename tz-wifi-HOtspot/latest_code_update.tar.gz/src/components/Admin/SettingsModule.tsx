import React, { useState, useEffect } from 'react';
import {
  Settings,
  Terminal,
  CreditCard,
  Mail,
  Database,
  RotateCcw,
  ShieldCheck,
  Server,
  Lock,
  Layers,
  ArrowRight,
  Flame,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Sparkles,
} from 'lucide-react';
import { HotspotOwner } from '../../types/index.ts';
import { VpsDevopsManager } from './VpsDevopsManager.tsx';
import { OwnerMerchantSettings } from './OwnerMerchantSettings.tsx';
import { EmailConfig } from './EmailConfig.tsx';
import { MySQLSchemaViewer } from './MySQLSchemaViewer.tsx';
import { SystemResetManager } from './SystemResetManager.tsx';
import { CompanyInfoSettings } from './CompanyInfoSettings.tsx';

export type SettingsSubTab =
  | 'company_info'
  | 'vps_devops'
  | 'payment_gateway'
  | 'email_gateway'
  | 'database_schema'
  | 'factory_reset';

interface SettingsModuleProps {
  currentUser: HotspotOwner | null;
  lang?: 'sw' | 'en';
  defaultSubTab?: SettingsSubTab;
  onResetCompleted?: () => void;
  onOwnerUpdated?: (updatedOwner: HotspotOwner) => void;
  onPreviewAbout?: () => void;
  onPreviewContact?: () => void;
}

export const SettingsModule: React.FC<SettingsModuleProps> = ({
  currentUser,
  lang = 'sw',
  defaultSubTab = 'company_info',
  onResetCompleted,
  onOwnerUpdated,
  onPreviewAbout,
  onPreviewContact,
}) => {
  const isVendor = currentUser?.role === 'VENDOR_ADMIN';

  // Available submodules
  // For VENDOR_ADMIN: all 5 submodules
  // For HOTSPOT_OWNER: vps_devops, payment_gateway, email_gateway (NO database_schema, NO factory_reset)
  const [activeSubTab, setActiveSubTab] = useState<SettingsSubTab>(() => {
    if (!isVendor && (defaultSubTab === 'database_schema' || defaultSubTab === 'factory_reset')) {
      return 'payment_gateway';
    }
    return isVendor ? defaultSubTab : 'payment_gateway';
  });

  // Ensure if role changes or unauthorized subtab is picked, fallback safely
  useEffect(() => {
    if (!isVendor && (activeSubTab === 'database_schema' || activeSubTab === 'factory_reset')) {
      setActiveSubTab('payment_gateway');
    }
  }, [isVendor, activeSubTab]);

  const subTabs = [
    {
      id: 'company_info' as const,
      labelSw: 'Taarifa za Mfumo (About & Contacts)',
      labelEn: 'System Info (About & Contacts)',
      descSw: 'Kuhusu sisi, simu, WhatsApp, ofisi, anwani na mitandao ya kijamii',
      descEn: 'About us, phone numbers, WhatsApp support, office and portal footer',
      icon: Building2,
      vendorOnly: false,
      badge: 'Public Portal',
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      id: 'vps_devops' as const,
      labelSw: 'Cloud VPS & FreeRADIUS',
      labelEn: 'Cloud VPS & FreeRADIUS',
      descSw: 'DevOps, Ubuntu 22.04, VPN WireGuard & CoA Port 3799',
      descEn: 'Ubuntu 22.04 server, WireGuard VPN & RADIUS CoA',
      icon: Terminal,
      vendorOnly: false,
      badge: 'DevOps',
      badgeColor: 'bg-indigo-100 text-indigo-700',
    },
    {
      id: 'payment_gateway' as const,
      labelSw: 'Payment Gateway (Geti la Malipo)',
      labelEn: 'Payment Gateway',
      descSw: 'DaliPay, PalmPay, AzamPay, Tigo/M-Pesa STK Push APIs',
      descEn: 'Automated mobile money gateways and merchant API keys',
      icon: CreditCard,
      vendorOnly: false,
      badge: currentUser?.palmpesa_user_id || currentUser?.payout_channel ? 'Active' : undefined,
      badgeColor: 'bg-emerald-100 text-emerald-700',
    },
    {
      id: 'email_gateway' as const,
      labelSw: 'Email & SMS Gateways',
      labelEn: 'Email & SMS Gateways',
      descSw: 'Resend, SendGrid, Mailgun, Beem Africa & NextSMS OTP (Real Dispatch)',
      descEn: 'Real transactional email & Tanzania SMS for OTP verification',
      icon: Mail,
      vendorOnly: false,
      badge: 'Real Dispatch',
      badgeColor: 'bg-emerald-100 text-emerald-800 font-bold',
    },
    {
      id: 'database_schema' as const,
      labelSw: 'Database Schema & MySQL',
      labelEn: 'Database Schema & MySQL',
      descSw: 'Muundo wa tables, SQL DDL na mahusiano ya data',
      descEn: 'Relational database schema, MySQL DDL & queries',
      icon: Database,
      vendorOnly: true,
      badge: 'Vendor HQ',
      badgeColor: 'bg-purple-100 text-purple-700',
    },
    {
      id: 'factory_reset' as const,
      labelSw: 'Factory Reset (Live Launch)',
      labelEn: 'Factory Reset (Live Launch)',
      descSw: 'Safi data za majaribio na uzindue mfumo rasmi live',
      descEn: 'Purge test transactions/vouchers and retain Vendor Admin',
      icon: RotateCcw,
      vendorOnly: true,
      badge: 'Vendor HQ',
      badgeColor: 'bg-rose-100 text-rose-700 font-bold',
    },
  ];

  // Filter accessible tabs
  const accessibleTabs = subTabs.filter((t) => !t.vendorOnly || isVendor);

  return (
    <div className="space-y-6">
      {/* Settings Module Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700">
              <Settings className="w-5 h-5 animate-spin-slow" />
            </span>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                {lang === 'sw' ? 'Mipangilio ya Mfumo (Settings)' : 'System Settings'}
              </h2>
              {isVendor ? (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                  👑 Vendor Master Access
                </span>
              ) : (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-900 border border-indigo-200">
                  🏢 {currentUser?.business_name || 'Hotspot Owner'}
                </span>
              )}
            </div>
          </div>
          <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
            {lang === 'sw'
              ? 'Sanidi miundombinu ya seva ya Cloud VPS & FreeRADIUS, mageti ya malipo ya simu, seva za barua pepe na usanidi wa kiufundi.'
              : 'Configure Cloud VPS & FreeRADIUS server infrastructure, mobile payment gateways, transactional email APIs, and technical operations.'}
          </p>
        </div>

        {/* Info pills */}
        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-600 font-medium">
            {accessibleTabs.length} {lang === 'sw' ? 'Submodules Zinazopatikana' : 'Accessible Submodules'}
          </span>
        </div>
      </div>

      {/* Submodule Navigation Tab Bar */}
      <div className="bg-slate-100/80 p-1.5 rounded-2xl border border-slate-200 overflow-x-auto scrollbar-none flex items-center gap-1.5">
        {accessibleTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer shrink-0 ${
                isActive
                  ? 'bg-white text-indigo-950 shadow-sm border border-slate-200/80'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Icon
                className={`w-4 h-4 ${
                  isActive
                    ? tab.id === 'factory_reset'
                      ? 'text-rose-600'
                      : 'text-indigo-600'
                    : 'text-slate-400'
                }`}
              />
              <span>{lang === 'sw' ? tab.labelSw : tab.labelEn}</span>
              {tab.badge && (
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded-md font-semibold ${
                    tab.badgeColor || 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Active Submodule Content */}
      <div className="transition-all duration-200">
        {/* 0. System Info (About & Contacts) */}
        {activeSubTab === 'company_info' && (
          <CompanyInfoSettings
            lang={lang}
            onPreviewAbout={onPreviewAbout}
            onPreviewContact={onPreviewContact}
          />
        )}

        {/* 1. Cloud VPS & FreeRADIUS */}
        {activeSubTab === 'vps_devops' && <VpsDevopsManager />}

        {/* 2. Payment Gateway */}
        {activeSubTab === 'payment_gateway' && (
          <OwnerMerchantSettings
            owner={currentUser}
            onUpdated={(updatedOwner: HotspotOwner) => {
              if (onOwnerUpdated) onOwnerUpdated(updatedOwner);
            }}
            lang={lang}
          />
        )}

        {/* 3. Email Merchant Gateway */}
        {activeSubTab === 'email_gateway' && <EmailConfig lang={lang} />}

        {/* 4. Database Schema (Vendor Only) */}
        {activeSubTab === 'database_schema' && isVendor && <MySQLSchemaViewer lang={lang} />}

        {/* 5. Factory Reset (Vendor Only) */}
        {activeSubTab === 'factory_reset' && isVendor && (
          <SystemResetManager
            onResetCompleted={onResetCompleted}
            lang={lang}
          />
        )}
      </div>
    </div>
  );
};
