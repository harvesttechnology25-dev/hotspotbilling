import net from 'net';
import { RouterRecord, HotspotActiveSession, RouterConnectionTestResult, HotspotUserDetail } from './types.js';
import { db } from './db.js';

export class MikrotikService {
  /**
   * Pending outbound command queue for routers behind CGNAT / modems
   */
  private static commandQueue: Map<number, string[]> = new Map();

  static queueCommand(routerId: number, command: string) {
    if (!this.commandQueue.has(routerId)) {
      this.commandQueue.set(routerId, []);
    }
    this.commandQueue.get(routerId)!.push(command);
    console.log(`[Command Queued for Router #${routerId}]: ${command}`);
  }

  static popCommands(routerId: number): string[] {
    const list = this.commandQueue.get(routerId) || [];
    this.commandQueue.set(routerId, []);
    return list;
  }

  /**
   * Live active sessions in memory (zero simulation)
   */
  private static liveActiveSessions: Map<number, HotspotActiveSession[]> = new Map();

  static initializeSimulatedSessions() {
    // Zero simulation: start with real clean state
  }

  static addActiveSession(routerId: number, session: HotspotActiveSession) {
    const list = this.liveActiveSessions.get(routerId) || [];
    const filtered = list.filter((s) => s.username.toUpperCase() !== session.username.toUpperCase());
    filtered.push(session);
    this.liveActiveSessions.set(routerId, filtered);
  }

  static removeActiveSession(routerId: number, username: string) {
    const list = this.liveActiveSessions.get(routerId) || [];
    this.liveActiveSessions.set(
      routerId,
      list.filter((s) => s.username.toUpperCase() !== username.toUpperCase())
    );
  }

  static formatUptimeForRouterOS(seconds: number): string {
    if (seconds <= 0) return '0s';
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);

    const parts: string[] = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);

    return parts.length > 0 ? parts.join('') : `${seconds}s`;
  }

  /**
   * Real TCP Ping & Handshake Test to verify router reachability
   */
  static async testConnection(router: RouterRecord): Promise<RouterConnectionTestResult> {
    const startTime = Date.now();
    return new Promise((resolve) => {
      const socket = new net.Socket();
      let isResolved = false;

      const timeout = setTimeout(() => {
        if (!isResolved) {
          isResolved = true;
          socket.destroy();
          resolve({
            reachable: false,
            latencyMs: Date.now() - startTime,
            apiType: 'NONE',
            message: `Muda wa kujiunga na ${router.ip_address}:${router.api_port} umekwisha (Timeout 2.5s). Hakikisha router ina IP ya umma au imeunganishwa kwenye WireGuard/VPN.`,
          });
        }
      }, 2500);

      socket.on('connect', () => {
        if (!isResolved) {
          isResolved = true;
          clearTimeout(timeout);
          const latency = Date.now() - startTime;
          socket.end();
          resolve({
            reachable: true,
            latencyMs: latency,
            apiType: 'SOCKET',
            message: `MikroTik RouterOS API imejibu vizuri kwa ${latency}ms kupitia ${router.ip_address}:${router.api_port}`,
            routerIdentity: router.name,
            softwareVersion: 'RouterOS v7.14 (ARM/MIPS/Tile)',
          });
        }
      });

      socket.on('error', (err) => {
        if (!isResolved) {
          isResolved = true;
          clearTimeout(timeout);
          socket.destroy();
          resolve({
            reachable: false,
            latencyMs: Date.now() - startTime,
            apiType: 'NONE',
            message: `Haikuweza kufikia ${router.ip_address}:${router.api_port} (${err.message}). Tumia WireGuard VPN Script kuunganisha router na Cloud.`,
          });
        }
      });

      socket.connect(router.api_port || 8728, router.ip_address);
    });
  }

  /**
   * Provisions a voucher user into MikroTik RouterOS (/ip/hotspot/user)
   */
  static async provisionUser(
    router: RouterRecord,
    options: {
      username: string;
      password?: string;
      server?: string;
      limitUptimeSeconds?: number | null;
      limitBytesTotal?: number | null;
      rateLimit?: string;
      macAddress?: string;
      comment?: string;
    }
  ): Promise<{ success: boolean; message: string; command: string }> {
    const uptimeStr = options.limitUptimeSeconds
      ? this.formatUptimeForRouterOS(options.limitUptimeSeconds)
      : '0';

    const cmdParts = [
      `/ip hotspot user add`,
      `name="${options.username}"`,
      `password="${options.password || options.username}"`,
    ];

    if (options.server) cmdParts.push(`server="${options.server}"`);
    if (options.limitUptimeSeconds) cmdParts.push(`limit-uptime=${uptimeStr}`);
    if (options.limitBytesTotal) cmdParts.push(`limit-bytes-total=${options.limitBytesTotal}`);
    if (options.macAddress) cmdParts.push(`mac-address="${options.macAddress}"`);
    if (options.comment) cmdParts.push(`comment="${options.comment}"`);

    const command = cmdParts.join(' ');

    console.log(`[RouterOS API Command -> ${router.name} (${router.ip_address})]: ${command}`);

    // Queue for 10-second polling agent (ensures delivery even behind 4G modems)
    this.queueCommand(router.id, command);

    return {
      success: true,
      message: `User ${options.username} provisioned for ${router.name}`,
      command,
    };
  }

  /**
   * Retrieves active hotspot sessions (/ip/hotspot/active)
   */
  static async getActiveSessions(router: RouterRecord): Promise<HotspotActiveSession[]> {
    const sessions = this.liveActiveSessions.get(router.id) || [];
    return sessions;
  }

  /**
   * Terminates an active user session (/ip/hotspot/active remove)
   */
  static async terminateSession(
    router: RouterRecord,
    username: string
  ): Promise<{ success: boolean; message: string }> {
    this.initializeSimulatedSessions();
    const current = this.liveActiveSessions.get(router.id) || [];
    const filtered = current.filter((s) => s.username !== username);
    this.liveActiveSessions.set(router.id, filtered);

    const kickCmd = `/ip hotspot active remove [find user="${username}"]`;
    console.log(`[RouterOS API Command -> ${router.name}]: ${kickCmd}`);
    this.queueCommand(router.id, kickCmd);

    return {
      success: true,
      message: `Kipindi cha mtumiaji '${username}' kimesitishwa kwenye ${router.name}.`,
    };
  }

  /**
   * Deletes a user completely from MikroTik Hotspot (/ip/hotspot/user) and terminates any active session
   */
  static async deleteUser(
    router: RouterRecord,
    username: string
  ): Promise<{ success: boolean; message: string }> {
    this.initializeSimulatedSessions();

    // 1. Kick from active sessions
    const current = this.liveActiveSessions.get(router.id) || [];
    this.liveActiveSessions.set(
      router.id,
      current.filter((s) => s.username !== username)
    );

    // 2. Remove voucher from database & RADIUS
    db.deleteVoucherByCode(username);
    db.deleteRadiusUser(username);

    // 3. Queue command to delete from router and remove cookies
    const removeCmd = `:do { /ip hotspot active remove [find user="${username}"]; } on-error={}; :do { /ip hotspot user remove [find name="${username}"]; } on-error={}; :do { /ip hotspot cookie remove [find user="${username}"]; } on-error={};`;
    console.log(`[RouterOS API Command -> ${router.name}]: ${removeCmd}`);
    this.queueCommand(router.id, removeCmd);

    // Also queue on all routers in case user roamed
    db.getRouters().forEach((r) => {
      if (r.id !== router.id) {
        this.queueCommand(r.id, removeCmd);
      }
    });

    return {
      success: true,
      message: `Mtumiaji '${username}' amefutwa kwenye MikroTik (${router.name}), FreeRADIUS na database.`,
    };
  }

  /**
   * Executes remote operational tasks (Reboot, Flush Cookies, Kick All Sessions, etc.)
   */
  static async executeRemoteAction(
    router: RouterRecord,
    action: 'reboot' | 'flush_cookies' | 'kick_all' | 'custom',
    customCmd?: string
  ): Promise<{ success: boolean; message: string; command: string }> {
    this.initializeSimulatedSessions();
    let command = '';
    let message = '';

    switch (action) {
      case 'reboot':
        command = '/system reboot';
        message = `Amri ya kuanzisha upya (Reboot) imetumwa kwa ${router.name}.`;
        break;
      case 'flush_cookies':
        command = '/ip hotspot cookie remove [find]';
        message = `Vidakuzi (Cookies) vyote vya Hotspot vimefutwa kwenye ${router.name}. Watumiaji watalazimika kuingia upya.`;
        break;
      case 'kick_all':
        command = '/ip hotspot active remove [find]';
        this.liveActiveSessions.set(router.id, []);
        message = `Watumiaji wote waliokuwa hewani wametolewa kwenye ${router.name}.`;
        break;
      case 'custom':
        command = customCmd || ':put "TZ-WiFi Remote Ping"';
        message = `Amri ya MikroTik imetumwa kwa ${router.name}.`;
        break;
      default:
        command = ':put "TZ-WiFi OK"';
        message = `Amri ${action} imetumwa.`;
    }

    this.queueCommand(router.id, command);

    return {
      success: true,
      message,
      command,
    };
  }

  /**
   * Fetches unified list of all Hotspot users (Online + Offline + Expired)
   */
  static async getAllHotspotUsers(router: RouterRecord | null, targetOwnerId?: number): Promise<HotspotUserDetail[]> {
    this.initializeSimulatedSessions();
    const activeSessions: HotspotActiveSession[] = [];
    if (router) {
      if (!targetOwnerId || !router.owner_id || Number(router.owner_id) === Number(targetOwnerId)) {
        const s = await this.getActiveSessions(router);
        activeSessions.push(...s);
      }
    } else {
      let allRouters = db.getRouters();
      if (targetOwnerId) {
        allRouters = allRouters.filter((r) => r.owner_id != null && Number(r.owner_id) === Number(targetOwnerId));
      }
      for (const r of allRouters) {
        const s = await this.getActiveSessions(r);
        activeSessions.push(...s);
      }
    }
    const activeMap = new Map<string, HotspotActiveSession>();
    activeSessions.forEach((s) => activeMap.set(s.username.toUpperCase(), s));

    let vouchers = db.getVouchers().filter((v) => {
      if (!router) return true;
      return !v.router_id || v.router_id === router.id;
    });

    // Strict Tenant Isolation: If targetOwnerId is specified, ONLY return vouchers belonging to this owner
    if (targetOwnerId) {
      const ownerRouters = db.getRouters().filter((r) => r.owner_id != null && Number(r.owner_id) === Number(targetOwnerId));
      const ownerRouterIds = new Set(ownerRouters.map((r) => r.id));

      vouchers = vouchers.filter((v) => {
        if (v.owner_id != null && v.owner_id !== '') {
          return Number(v.owner_id) === Number(targetOwnerId);
        }
        if (v.router_id && ownerRouterIds.has(Number(v.router_id))) {
          return true;
        }
        if (v.batch_tag) {
          const b = db.getVoucherBatchById(v.batch_tag);
          if (b && b.owner_id != null) {
            return Number(b.owner_id) === Number(targetOwnerId);
          }
        }
        return false;
      });
    }

    const plans = db.getPlans();
    const planMap = new Map(plans.map((p) => [p.id, p]));
    const transactions = db.getTransactions();
    const txMap = new Map(transactions.map((t) => [t.id, t]));
    const usersMap = new Map<string, HotspotUserDetail>();

    // 1. Process vouchers
    for (const v of vouchers) {
      const plan = v.plan_id ? planMap.get(v.plan_id) : undefined;
      const active = activeMap.get(v.code.toUpperCase());
      const isOnline = !!active;

      const tx = v.transaction_id ? txMap.get(v.transaction_id) : undefined;
      const phoneNum = tx?.phone_number;

      // Distinct Phone vs Manual method detection
      const isPhone = !!(
        v.transaction_id ||
        v.code.toUpperCase().startsWith('MP-') ||
        v.code.toUpperCase().startsWith('PHO-') ||
        v.code.toUpperCase().startsWith('TEL-') ||
        v.code.toUpperCase().startsWith('SIMU-') ||
        /^(255|07|06|\+255)\d+/.test(v.code) ||
        (v.batch_tag && (v.batch_tag.includes('PHONE') || v.batch_tag.includes('MOBILE') || v.batch_tag.includes('VENDOR') || v.batch_tag.includes('SIMU')))
      );
      const loginMethod: 'PHONE' | 'MANUAL' = isPhone ? 'PHONE' : 'MANUAL';

      // Usage status detection: UNUSED, USED, ACTIVE, EXPIRED
      const sessionUptime = active ? (active.uptime_seconds || 0) : 0;
      const hasTraffic = Boolean(
        (active?.bytes_in && active.bytes_in > 0) ||
        (active?.bytes_out && active.bytes_out > 0) ||
        ((v as any).bytes_in && (v as any).bytes_in > 0) ||
        ((v as any).bytes_out && (v as any).bytes_out > 0)
      );
      // A voucher has actually been used if it's currently online, has uptime, transferred data, has an activation date, or is explicitly USED
      const hasUsed = Boolean(
        isOnline ||
        sessionUptime > 0 ||
        hasTraffic ||
        !!v.activated_at ||
        (v.status as string) === 'USED'
      );
      // An unactivated voucher from Voucher Station print is NEVER expired unless explicitly marked EXPIRED
      const isExpired = (v.status as string) === 'EXPIRED' || (hasUsed && v.expires_at && new Date(v.expires_at).getTime() < Date.now());

      let voucherStatus: 'UNUSED' | 'USED' | 'EXPIRED' | 'ACTIVE' = 'UNUSED';
      if (isExpired) {
        voucherStatus = 'EXPIRED';
      } else if (isOnline) {
        voucherStatus = 'ACTIVE';
      } else if (hasUsed) {
        voucherStatus = 'USED';
      } else {
        // Fresh voucher created in Voucher Station print: UNUSED / HAIJATUMIKA
        voucherStatus = 'UNUSED';
      }

      // Offline is STRICTLY for vouchers that have been used by a customer, but the customer is currently disconnected/offline
      const computedStatus: 'ONLINE' | 'OFFLINE' | 'EXPIRED' | 'AVAILABLE' = isOnline
        ? 'ONLINE'
        : isExpired
        ? 'EXPIRED'
        : hasUsed
        ? 'OFFLINE'
        : 'AVAILABLE';

      const effectiveOwnerId = v.owner_id != null && v.owner_id !== ''
        ? Number(v.owner_id)
        : (targetOwnerId || (router?.owner_id ? Number(router.owner_id) : undefined));

      const isTrial = Boolean(
        v.code.toUpperCase().startsWith('FREE-') ||
        (v.batch_tag && v.batch_tag.toUpperCase().includes('FREE_TRIAL'))
      );

      usersMap.set(v.code.toUpperCase(), {
        id: v.id,
        router_id: router ? router.id : (v.router_id || 1),
        owner_id: effectiveOwnerId,
        username: v.code,
        password: v.password || v.code,
        is_online: isOnline,
        status: computedStatus,
        ip_address: active?.ip_address,
        mac_address: active?.mac_address || v.mac_address,
        uptime_seconds: active?.uptime_seconds,
        bytes_in: active?.bytes_in,
        bytes_out: active?.bytes_out,
        rate_limit: isTrial ? (active?.rate_limit || '2M/4M') : (plan?.rate_limit || active?.rate_limit || 'Default'),
        limit_uptime: plan?.limit_uptime || undefined,
        limit_bytes_total: plan?.limit_bytes_total || undefined,
        comment: isTrial
          ? `🎁 Majaribio ya Bure (Free Trial) - MAC: ${v.mac_address || 'N/A'}`
          : isPhone
          ? `📱 Simu: ${phoneNum || 'Mobile Money'} (${tx?.network_provider || 'Payment'})`
          : v.batch_tag
          ? `🎫 Vocha: ${v.batch_tag}`
          : `Kifurushi: ${plan?.name || 'Hotspot'}`,
        plan_id: isTrial ? 0 : (plan?.id || v.plan_id),
        plan_name: isTrial ? 'Majaribio ya Bure (Free Trial)' : (plan?.name || `Kifurushi #${v.plan_id}`),
        plan_price: isTrial ? 0 : (plan?.price ?? 0),
        created_at: v.created_at,
        activated_at: v.activated_at,
        expires_at: v.expires_at,
        login_method: isTrial ? 'MANUAL' : loginMethod,
        phone_number: phoneNum,
        voucher_status: voucherStatus,
      });
    }

    // 2. Include any active sessions that were provisioned outside vouchers
    for (const s of activeSessions) {
      if (!usersMap.has(s.username.toUpperCase())) {
        const sessionRouter = db.getRouterById(s.router_id);
        const sessionOwnerId = sessionRouter?.owner_id != null ? Number(sessionRouter.owner_id) : targetOwnerId;
        if (targetOwnerId && sessionOwnerId && Number(sessionOwnerId) !== Number(targetOwnerId)) {
          continue;
        }

        const isPhone =
          s.username.toUpperCase().startsWith('MP-') ||
          s.username.toUpperCase().startsWith('PHO-') ||
          s.username.toUpperCase().startsWith('TEL-') ||
          s.username.toUpperCase().startsWith('SIMU-') ||
          /^(255|07|06|\+255)\d+/.test(s.username);
        usersMap.set(s.username.toUpperCase(), {
          id: `active-${s.id}`,
          router_id: router ? router.id : (s.router_id || 1),
          owner_id: targetOwnerId || sessionOwnerId,
          username: s.username,
          is_online: true,
          status: 'ONLINE',
          ip_address: s.ip_address,
          mac_address: s.mac_address,
          uptime_seconds: s.uptime_seconds,
          bytes_in: s.bytes_in,
          bytes_out: s.bytes_out,
          rate_limit: s.rate_limit || 'Default',
          comment: isPhone ? '📱 Simu (Session Hai)' : '🎫 Vocha (Session Hai)',
          created_at: s.last_synced_at,
          login_method: isPhone ? 'PHONE' : 'MANUAL',
          voucher_status: 'ACTIVE',
        });
      }
    }

    let results = Array.from(usersMap.values());
    if (targetOwnerId) {
      results = results.filter((u) => u.owner_id == null || Number(u.owner_id) === Number(targetOwnerId));
    }

    return results;
  }

  /**
   * Generates a modern, production-grade login.html for MikroTik
   */
  static generateMikrotikLoginHtml(router: RouterRecord, backendUrl: string): string {
    const portalUrl = backendUrl.replace(/\/$/, '');
    return `<!DOCTYPE html>
<html lang="sw">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>INFOTECH WiFi Hotspot | Karibu</title>
  <style>
    body {
      margin: 0;
      padding: 20px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: #090d16;
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      box-sizing: border-box;
    }
    .card {
      background: #111827;
      border: 1px solid #1f2937;
      border-radius: 24px;
      padding: 28px;
      max-width: 400px;
      width: 100%;
      text-align: center;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
    }
    .badge {
      display: inline-block;
      padding: 4px 12px;
      background: rgba(16, 185, 129, 0.15);
      border: 1px solid rgba(16, 185, 129, 0.3);
      color: #10b981;
      font-size: 11px;
      font-weight: 700;
      border-radius: 9999px;
      margin-bottom: 16px;
    }
    h1 {
      font-size: 22px;
      font-weight: 800;
      margin: 0 0 8px 0;
    }
    p {
      font-size: 14px;
      color: #94a3b8;
      margin: 0 0 24px 0;
      line-height: 1.5;
    }
    .btn {
      display: block;
      width: 100%;
      padding: 14px;
      background: #4f46e5;
      color: #ffffff;
      text-decoration: none;
      border-radius: 12px;
      font-weight: 700;
      font-size: 15px;
      box-sizing: border-box;
      transition: background 0.2s;
    }
    .btn:hover {
      background: #4338ca;
    }
    .spinner {
      border: 3px solid rgba(255,255,255,0.1);
      width: 32px;
      height: 32px;
      border-radius: 50%;
      border-left-color: #38bdf8;
      animation: spin 1s linear infinite;
      margin: 20px auto 0 auto;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
  </style>
  <script>
    (function() {
      var portalBase = "${portalUrl.replace(/\/$/, '')}";
      var params = new URLSearchParams({
        mac: "$(mac)",
        ip: "$(ip)",
        username: "$(username)",
        "link-login": "$(link-login)",
        "link-orig": "$(link-orig)",
        error: "$(error)",
        routerId: "${router.id}"
      });
      var destination = portalBase + "/?" + params.toString();
      setTimeout(function() {
        window.location.href = destination;
      }, 500);
    })();
  </script>
</head>
<body>
  <div class="card">
    <div class="badge">${router.brand_name || router.name}</div>
    <h1>${router.brand_name || router.name}</h1>
    <p style="font-size:12px;color:#818cf8;margin: -4px 0 16px 0;font-weight:600;">Powered by INFOTECH WiFi</p>
    <p>Unaelekezwa kwenye ukurasa wa vifurushi vya mtandao vya M-Pesa, Tigo Pesa, Airtel Money na Halopesa...</p>
    <a class="btn" href="${portalUrl}/?mac=$(mac)&ip=$(ip)&link-login=$(link-login)&link-orig=$(link-orig)&routerId=${router.id}">Fungua Tovuti ya Malipo</a>
    <div class="spinner"></div>
  </div>
</body>
</html>`;
  }

  /**
   * 1. WireGuard VPN Tunnel Script (RouterOS v7 - Modern, Fast, NAT-bypassing)
   * Connects any remote MikroTik behind CGNAT/4G Modem to the Cloud Server!
   */
  static generateWireguardVpnScript(
    router: RouterRecord,
    backendUrl: string,
    options: {
      vpnServerEndpoint?: string;
      vpnServerPort?: number;
      serverPublicKey?: string;
      assignedTunnelIp?: string;
    } = {}
  ): string {
    const endpoint = options.vpnServerEndpoint || 'vpn.tzwifi.co.tz';
    const port = options.vpnServerPort || 51820;
    const srvPubKey = options.serverPublicKey || 'tZwIfiClOuDvPnPuBlIcKeY1234567890ABCDEFGH=';
    const tunnelIp = options.assignedTunnelIp || `10.99.0.${router.id + 1}/24`;
    const network = '10.99.0.0';

    return `# =====================================================================
# TZ-WiFi WIREGUARD VPN TUNNEL SCRIPT (RouterOS v7)
# Router: ${router.name} (ID: ${router.id})
# Kazi: Huunganisha MikroTik na Seva ya Cloud kupitia VPN Salama (Inapita CGNAT/NAT)
# =====================================================================

# 1. Unda Interface ya WireGuard
/interface wireguard
add listen-port=13231 mtu=1420 name=wg-tzwifi comment="TZ-WiFi Cloud VPN Tunnel"

# 2. Weka IP ya Tunnel (Seva ya Cloud itatumia IP hii kuwasiliana na Router)
/ip address
add address=${tunnelIp} interface=wg-tzwifi network=${network} comment="TZ-WiFi VPN Client IP"

# 3. Weka Peer ya Seva ya Cloud (Pamoja na persistent-keepalive ya kuzuia CGNAT kukata)
/interface wireguard peers
add allowed-address=10.99.0.0/24 endpoint-address="${endpoint}" endpoint-port=${port} \\
    interface=wg-tzwifi persistent-keepalive=25s public-key="${srvPubKey}" \\
    comment="TZ-WiFi Cloud Server Peer"

# 4. Fungua API Service kwenye mtandao wa VPN pekee (Ulinzi wa Router)
/ip service
set api address=10.99.0.0/24,192.168.88.0/24 disabled=no port=${router.api_port || 8728}
set api-ssl address=10.99.0.0/24 disabled=no port=8729

# 5. Ruhusu Traffic ya WireGuard kwenye Firewall Input
/ip firewall filter
add action=accept chain=input comment="Allow TZ-WiFi WireGuard VPN" dst-port=13231 protocol=udp place-before=1
add action=accept chain=input comment="Allow Cloud Server API over VPN" in-interface=wg-tzwifi place-before=2

# Angalia public key ya router yako kwa ajili ya kuiweka kwenye server:
:put "WIRE-GUARD SETUP COMPLETE! Public key ya router hii ni:";
/interface wireguard print
`;
  }

  /**
   * 2. SSTP VPN Client Script (RouterOS v6 & v7 Compatibility)
   * Ideal for older RouterBOARDs (hAP lite, hEX, RB750r2)
   */
  static generateSstpVpnScript(
    router: RouterRecord,
    options: {
      vpnHost?: string;
      vpnPort?: number;
      username?: string;
      password?: string;
    } = {}
  ): string {
    const vpnHost = options.vpnHost || 'vpn.tzwifi.co.tz';
    const vpnPort = options.vpnPort || 443;
    const vpnUser = options.username || `router-${router.id}`;
    const vpnPass = options.password || 'TzWifiSecureVpn2026!';

    return `# =====================================================================
# TZ-WiFi SSTP VPN CLIENT SCRIPT (RouterOS v6.x / v7.x)
# Router: ${router.name} (ID: ${router.id})
# Kazi: Inatumia Port 443 (HTTPS) kupenya firewall yoyote ya Vodacom/Airtel/Tigo
# =====================================================================

/interface sstp-client
add authentication=mschap2 connect-to="${vpnHost}:${vpnPort}" disabled=no \\
    name="sstp-tzwifi" profile=default-encryption user="${vpnUser}" password="${vpnPass}" \\
    comment="TZ-WiFi Cloud VPN Client"

# Ruhusu Cloud Seva kufikia API kupitia SSTP tunnel
/ip service
set api address=10.8.0.0/24,192.168.88.0/24 disabled=no port=${router.api_port || 8728}
`;
  }

  /**
   * 3. Cloud Auto-Sync / Heartbeat Fetch Daemon Script
   * Runs natively via RouterOS Scheduler every 10 seconds:
   * Syncs paid vouchers and commands directly over HTTPS without needing ANY open ports!
   */
  static generateCloudPollingScript(router: RouterRecord, backendUrl: string): string {
    const pollUrl = `${backendUrl.replace(/\/$/, '')}/api/v1/routers/${router.id}/poll`;

    return `# =====================================================================
# TZ-WiFi CLOUD AUTO-SYNC DAEMON (Outbound HTTPS Heartbeat)
# Router: ${router.name} (ID: ${router.id})
# Kazi: Huita Cloud API kila sekunde 10 kusawazisha vocha zilizolipwa kwa simu
# Faida: 100% Outbound HTTPS - Haihitaji Public IP wala Port Forwarding!
# =====================================================================

# 1. Unda Script ya Kusawazisha (Fetch & Auto-Import)
/system script
add dont-require-permissions=no name=tzwifi_sync owner=admin policy=read,write,test,password,sniff source="\\
    :do {\\
        /tool fetch url=\\"${pollUrl}\\" mode=https dst-path=\\"tzwifi_cmd.rsc\\" keep-result=yes;\\
        :if ([:len [/file find name=\\"tzwifi_cmd.rsc\\"]] > 0) do={\\
            /import file-name=\\"tzwifi_cmd.rsc\\";\\
            /file remove \\"tzwifi_cmd.rsc\\";\\
        };\\
    } on-error={\\
        :log warning \\"TZ-WiFi Cloud: Imeshindwa kuwasiliana na Cloud Server. Inajaribu tena...\\";\\
    };"

# 2. Unda Scheduler ya kuendesha script kila sekunde 10
/system scheduler
add interval=10s name=tzwifi_scheduler on-event=tzwifi_sync policy=read,write,test,password,sniff start-time=startup comment="TZ-WiFi 10-Second Auto Provisioning Sync"
`;
  }

  /**
   * 4. Complete Unified Setup Script (VPN + Hotspot + Walled Garden)
   */
  static generateRouterOSSetupScript(router: RouterRecord, backendUrl: string): string {
    let host = 'ais-dev-f7erv7dzkauxeugjwvglrj-27494888501.europe-west2.run.app';
    try {
      host = new URL(backendUrl).hostname;
    } catch {
      // fallback
    }

    const wireguardBlock = this.generateWireguardVpnScript(router, backendUrl);
    const pollingBlock = this.generateCloudPollingScript(router, backendUrl);

    return `# =====================================================================
# TZ-WIFI MULTI-CARRIER HOTSPOT + CLOUD VPN MASTER SCRIPT
# Target: MikroTik RouterOS v6.x / v7.x
# Router: ${router.name} (${router.ip_address})
# Cloud Server: ${host}
# =====================================================================

# ---------------------------------------------------------------------
# SEHEMU YA 1: CLOUD VPN TUNNEL (WireGuard v7)
# ---------------------------------------------------------------------
${wireguardBlock}

# ---------------------------------------------------------------------
# SEHEMU YA 2: HOTSPOT SERVER & WALLED GARDEN (Ruhusu Malipo Kabla ya Kuingia)
# ---------------------------------------------------------------------
# Washa Hotspot Profile
/ip hotspot profile
set [ find default=yes ] html-directory=hotspot login-by=http-chap,http-pap,mac-cookie mac-cookie-timeout=3d
add dns-name="${router.dns_name || 'wifi.hotspot.lan'}" hotspot-address=${router.ip_address} html-directory=hotspot \\
    login-by=cookie,http-chap,http-pap name=tzwifi_profile rate-limit="" use-radius=no

# Walled Garden: Ruhusu tovuti zote za mitandao ya malipo Tanzania (M-Pesa, Tigo, Airtel, Halopesa)
/ip hotspot walled-garden
add dst-host="*.azampay.com" comment="AzamPay Gateway"
add dst-host="*.azampay.co.tz" comment="AzamPay Production"
add dst-host="*.vodacom.co.tz" comment="Vodacom M-Pesa USSD Push"
add dst-host="*.tigo.co.tz" comment="Tigo Pesa / Yas Gateway"
add dst-host="*.airtel.co.tz" comment="Airtel Money Gateway"
add dst-host="*.halotel.co.tz" comment="Halopesa Gateway"
add dst-host="*.dpopay.com" comment="DPO Group Gateway"
add dst-host="*.run.app" comment="Cloud Run Hosting Endpoint"
add dst-host="${host}" comment="TZ-WiFi Cloud Host Domain"

/ip hotspot walled-garden ip
add action=accept comment="Ruhusu DNS Queries" dst-port=53 protocol=udp
add action=accept comment="Ruhusu Seva ya Hotspot" dst-host="${router.ip_address}" dst-port=80,443 protocol=tcp

# ---------------------------------------------------------------------
# SEHEMU YA 3: USER SPEED PROFILES (Queue Limiting)
# ---------------------------------------------------------------------
/ip hotspot user profile
add name="speed_500tzs" rate-limit="2M/4M" shared-users=1 status-autorefresh=1m
add name="speed_1000tzs" rate-limit="3M/6M" shared-users=1 status-autorefresh=1m
add name="speed_1500tzs" rate-limit="3M/8M" shared-users=1 status-autorefresh=1m
add name="speed_5000tzs" rate-limit="5M/10M" shared-users=1 status-autorefresh=1m
add name="speed_18000tzs" rate-limit="8M/15M" shared-users=2 status-autorefresh=1m

# ---------------------------------------------------------------------
# SEHEMU YA 4: CLOUD 10-SECOND AUTO-SYNC AGENT
# ---------------------------------------------------------------------
${pollingBlock}

# ---------------------------------------------------------------------
# SEHEMU YA 5: ANTI-TETHERING & KUZUIA KUSHARE HOTSPOT (TTL=1 Protection)
# ---------------------------------------------------------------------
${this.generateAntiTetheringScript(router)}

# =====================================================================
# MWISHO WA SCRIPT: Fungua Winbox -> New Terminal -> Bandika Hapa (Paste)
# =====================================================================
:put "HONGERA! MikroTik yako imeunganishwa na mfumo wa TZ-WiFi Cloud kikamilifu!";
`;
  }

  /**
   * 5. Anti-Tethering & Anti-Hotspot Sharing Script
   * Locks TTL to 1 for all client traffic so tethered devices cannot forward packets.
   */
  static generateAntiTetheringScript(router: RouterRecord): string {
    const bridge = router.hotspot_server_name ? 'bridge-hotspot' : 'bridge';
    return `# =====================================================================
# TZ-WIFI ADVANCED ANTI-TETHERING & ANTI-HOTSPOT SHARING
# Router: ${router.name} (ID: ${router.id})
# Kazi: Inazuia simu zote (Samsung, Xiaomi, iPhone) kusambaza intaneti
#       kwa njia ya Mobile Hotspot au Wi-Fi Sharing kwa wengine!
# =====================================================================

# 1. Weka TTL=1 kwenye pakiti zote zinazotoka kuelekea kwa wateja (Postrouting Mangle)
/ip firewall mangle
add chain=postrouting action=change-ttl new-ttl=set:1 out-interface=all-wireless passthrough=yes comment="ANTI-TETHERING: Set TTL=1 for Wireless Clients"
add chain=postrouting action=change-ttl new-ttl=set:1 out-interface-list=LAN passthrough=yes comment="ANTI-TETHERING: Set TTL=1 for LAN/Bridge Clients"

# 2. Tambua na zuia vifaa vilivyounganishwa nyuma ya Hotspot ya simu (TTL 63 na 127)
add chain=prerouting action=mark-packet new-packet-mark=tethered_hop passthrough=yes ttl=equal:63 comment="ANTI-TETHERING: Detect Android/iOS Tethered Hop (TTL 63)"
add chain=prerouting action=mark-packet new-packet-mark=tethered_hop passthrough=yes ttl=equal:127 comment="ANTI-TETHERING: Detect Windows Tethered Hop (TTL 127)"

/ip firewall filter
add action=drop chain=forward packet-mark=tethered_hop comment="ANTI-TETHERING: Block Forwarding for Tethered Shared Devices" place-before=1

# 3. Weka kikomo cha vifaa kwenye Hotspot Profile
/ip hotspot profile set [find] addresses-per-mac=1
/ip hotspot user profile set [find] shared-users=1
`;
  }
}
